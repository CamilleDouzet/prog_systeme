#! /bin/bash
gcc -o server server.c
gcc -o serverDGSE serverDGSE.c
gcc -o client client.c
