extern int fonctionCool(int,int);
