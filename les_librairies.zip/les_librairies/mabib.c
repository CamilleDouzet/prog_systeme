#include "mabib.h"

int fonctionCool(int a1, int a2)
{
	return a1+a2;
}

